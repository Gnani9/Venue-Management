//
//  Constant.swift
//  WeatherApp
//
//  Created by Haris Madhavan on 06/09/23.
//

import Foundation
import UIKit

public class Constants {
    var userId : String? {
        return UserDefaultsManager.shared.getUserName()
    }
 
    enum serviceType: String {
        
        case loginAPI = "http://192.168.179.232//ios/login.php?email=suresh@gmail.com&password=suresh1"
        case UresourceAPI = "http://192.168.179.232//ios/Uresourceperson.php?"
        
        
        
        static var ProfileAPI : String {
            if let userId = Constants().userId {
                return "http://192.168.179.232//ios/iprofile.php?user_id=\(userId)"
            }
            else {
                return ""
            }
        }
        case signUpUrl = "http://192.168.179.232/ios/usignup.php"
        case forgotUrl = "http://192.168.179.232/ios/forgotpassword.php"
        case forecasturl = "https://api.openweathermap.org/data/2.5/onecall?lat=33.44&lon=-94.04&appid=4cd569ffb3ecc3bffe9c0587ff02109f"
    }
    
    static let loginUrl: serviceType = .loginAPI
    static let signUpUrl: serviceType = .signUpUrl
    static let forgotUrl: serviceType = .forgotUrl
    static let forecast: serviceType = .forecasturl
}
