import Foundation


struct HistoryStruct: Codable {
    let status: Bool
    let data: [HistoryClass]
}

// MARK: - Datum
struct HistoryClass: Codable {
    let venue, title, date, startTime: String
    let endTime: String

    enum CodingKeys: String, CodingKey {
        case venue = "Venue"
        case title = "Title"
        case date = "Date"
        case startTime = "StartTime"
        case endTime = "EndTime"
    }
}
