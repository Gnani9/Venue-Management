import Foundation

// MARK: - Welcome
struct Venue: Codable {
    var status: Bool?
    var message: String?
}
