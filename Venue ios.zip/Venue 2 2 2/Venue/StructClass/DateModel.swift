
import Foundation

// MARK: - Welcome
struct DateModel: Codable {
    var data: [DateDatum]?
}

// MARK: - Datum
struct DateDatum: Codable {
    var date, starttime, endtime, capacity: String?
}
