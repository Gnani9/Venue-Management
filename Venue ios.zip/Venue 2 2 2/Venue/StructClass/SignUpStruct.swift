//
//  SignUpStruct.swift
//  Venue
//
//  Created by SAIL on 28/10/23.
//

import Foundation

// MARK: - Welcome
struct SignUpStruct: Codable {
    var success: Bool?
    var message: String?
}
