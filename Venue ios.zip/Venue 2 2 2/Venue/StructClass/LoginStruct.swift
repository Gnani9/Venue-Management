//
//  LoginStruct.swift
//  Venue
//
//  Created by SAIL on 11/10/23.
//

import Foundation


struct LoginStruct : Codable {
    let status : Bool?
    let message : String?
    let data : Data?
}
struct Data : Codable {
    
    let user_id : String?
    let username : String?
    let password : String?
    let email : String?
    
}

