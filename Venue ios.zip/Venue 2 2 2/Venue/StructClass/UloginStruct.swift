//
//  UloginStruct.swift
//  Venue
//
//  Created by SAIL on 19/10/23.
//
import Foundation

// MARK: - Welcome
struct UloginStruct: Codable {
    let status: Bool
    let message: String
    let data: Data1?
}

// MARK: - DataClass
struct Data1: Codable {
    let uusername, upassword, name, email: String
    let mobileNo: String

    enum CodingKeys: String, CodingKey {
        case uusername, upassword, name, email
        case mobileNo = "mobile no"
    }
}
