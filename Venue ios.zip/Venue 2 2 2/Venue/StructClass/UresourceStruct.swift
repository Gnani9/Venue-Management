
import Foundation

// MARK: - Welcome
struct UresouceStruct: Codable {
    var data: [ResData]?
}

// MARK: - Datum
struct ResData: Codable {
    var name, designation: String?
}
