//
//  ProfileStruct.swift
//  Venue
//
//  Created by SAIL on 13/10/23.
//

import Foundation

// MARK: - Welcome
struct ProfileJSON: Codable {
    let status: Bool
    let data: [Datum]
}

// MARK: - Datum
struct Datum: Codable {
    let username, email, phone: String
}

