
import Foundation

// MARK: - Welcome
struct EventStruct : Codable	 {
    let data: [EventData]?
}

// MARK: - Datum
struct EventData : Codable {
    let id, venueName, category, title: String?
    let date, starttime, endtime: String?
}
