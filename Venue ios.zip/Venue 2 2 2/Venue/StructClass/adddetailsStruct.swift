//
//  AddDetailsStruct.swift
//  Venue
//
//  Created by SAIL on 12/10/23.
//

import Foundation


struct AddDetailsModel: Codable {
    let status: Bool
    let message: String
}
