//
//  SettingsVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class SettingsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func logout(_ sender: Any) {
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC")as!LoginVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
        
    }
    
    @IBAction func Profile(_ sender: Any) {
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileVC")as!ProfileVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    
    @IBAction func HistoryVC(_ sender: Any) {
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HistoryVC")as!HistoryVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
