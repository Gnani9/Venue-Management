//
//  UresourceVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class UresourceVC: UIViewController {

    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Designation: UILabel!
    let apiHandler : APIHandler = APIHandler()
    var apiData : UresouceStruct!
    var apiUrl = String()
    var id = String()

    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
       GetAPI()
       }
    
    
    @IBAction func contin(_ sender: Any) {
           let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UdateVC")as! UdateVC
        nextvc.id = id
           self.navigationController?.pushViewController(nextvc, animated: true)
       }
   

          
          func GetAPI(){
              
              APIHandler().getAPIValues(type: UresouceStruct.self, apiUrl: "http://192.168.179.232/ios/sresourceperson.php?id=\(id)", method: "GET") {
                  result in
                  switch result {
                  case .success(let data):
                      self.apiData = data
                      print(data)
                      DispatchQueue.main.async { 
                          self.Name.text = "Name: \(self.apiData.data?.first?.name ?? "")"
                          self.Designation.text = "Designation : \(self.apiData.data?.first?.designation ?? "")"
                          
                           
                      }
                      
                      
                  case .failure(let error):
                      print(error)
                      
                  }
              }
              
          }
}
