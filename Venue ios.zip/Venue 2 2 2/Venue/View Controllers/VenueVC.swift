import UIKit

class VenueVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    
    @IBOutlet weak var venueCollectionView: UICollectionView!
    
    var venueArray = ["Lines Hall","Lattice Hall","Majestorium","Nalli Arangam"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.venueCollectionView.delegate = self
        self.venueCollectionView.dataSource = self

    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        self.venueArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "venueCell", for: indexPath) as! venueCell
              
              
        cell.venueBtn.setTitle(self.venueArray[indexPath.row], for: .normal) //= self.venueArray[indexPath.row]
              return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            
            
        print("You selected cell #\(indexPath.item) v!")
        if indexPath.row == 0 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
        
        let ViewController = self.storyboard?.instantiateViewController(withIdentifier: "DateVC") as! DateVC
        self.navigationController?.pushViewController(ViewController, animated: true)
        }
        }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
         let padding: CGFloat =  25
            let collectionViewSize = collectionView.frame.size.width - padding
            return CGSize(width: collectionViewSize/2, height: 150
            )
        }

}

class venueCell : UICollectionViewCell{
    
    
    
    @IBOutlet weak var venueView: UIImageView!
    @IBOutlet weak var venueBtn: UIButton!
}



