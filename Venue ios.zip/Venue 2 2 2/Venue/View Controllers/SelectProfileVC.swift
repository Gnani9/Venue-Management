//
//  SelectProfileVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class SelectProfileVC: UIViewController {
    @IBOutlet weak var Ulogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func adminLogin(_ sender: Any) {
        UserDefaultsManager.shared.saveUserId("Admin")
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC")as! LoginVC
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    
    @IBAction func Ulogin(_ sender: Any) {
        UserDefaultsManager.shared.saveUserId("User")

        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UloginVC") as! UloginVC
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
}
