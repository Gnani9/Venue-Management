//
//  DateVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class DateVC: UIViewController {

    @IBOutlet weak var startTimeDatePicker: UIDatePicker!
    @IBOutlet weak var date: UIDatePicker!
    @IBOutlet weak var EndTimeDatePicker: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func con(_ sender: Any) {
        self.SelectDateTime()

    }
    
    func SelectDateTime() {
        // Get the selected dates and times from the date pickers
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let selectedDate = dateFormatter.string(from: date.date)

        dateFormatter.dateFormat = "HH:mm:ss"
        let selectedStartTime = dateFormatter.string(from: startTimeDatePicker.date)
        let selectedEndTime = dateFormatter.string(from: EndTimeDatePicker.date)

        // Create the parameters dictionary with dynamic values
        let parameters: [String: String] = [
            "date": selectedDate,
            "starttime": selectedStartTime,
            "endtime": selectedEndTime
        ]

        // Use dynamic values in your API call
        APIHandler().postAPIValues(type: ResGetModel.self, apiUrl: "http://192.168.179.232/ios/icalendar.php", method: "POST", formData: parameters) { Result in
            switch Result {
            case .success(let Data):
                print(Data)
                DispatchQueue.main.async {
                    let nextvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AresourceVC") as! AresourceVC
                    self.navigationController?.pushViewController(nextvc, animated: true)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    

}
