//
//  UloginVC.swift
//  Venue
//
//  Created by SAIL on 19/10/23.
//

import UIKit

class UloginVC: UIViewController {

    @IBOutlet weak var UloginVC: UIButton!
    @IBOutlet weak var uusername: UITextField!
    @IBOutlet weak var upassword: UITextField!
    @IBOutlet weak var signup: UIButton!
    var loginDetails = UloginStruct.self
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Ulogin(_ sender: Any) {
        APIHandler().getAPIValues(type: LoginStruct.self, apiUrl: "http://192.168.179.232/ios/ulogin.php?uusername=\(uusername.text ?? "")&upassword=\(upassword.text ?? "")", method: "GET") { Result in
            switch Result {
            case .success(let data):
                print(data)
                
                DispatchQueue.main.async {
                    if data.status == true {
                        let nextvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarViewController")as!  TabBarViewController;
                         self.navigationController?.pushViewController(nextvc, animated: true)
                    }else {
                        print(data.status)
                    }
                    
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

            case .failure(let error):
                print(error)
                }
        }
    
    }
    @IBAction func signup(_ sender: Any) {
        let nextvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignupVC")as!SignupVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
        
    }
    
}

