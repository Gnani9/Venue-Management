//
//  LoginVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class LoginVC: UIViewController {
    @IBOutlet weak var Login: UIButton!
    
    @IBOutlet weak var userLbl: UILabel!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var userName: UITextField!
    var loginDetails = LoginStruct.self
    
           
    override func viewDidLoad() {
        super.viewDidLoad()

        SelectProfileLogin()
    }
    
    @IBAction func Login(_ sender: Any) {

        
        APIHandler().getAPIValues(type: LoginStruct.self, apiUrl: "http://192.168.179.232/ios/ilogin.php?username=\(userName.text ?? "")&password=\(passwordTF.text ?? "")", method: "GET") { Result in
            switch Result {
            case .success(let data):
                print(data)
                
                DispatchQueue.main.async {
                    if data.status == true {
                        let nextvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarViewController")as!  TabBarViewController;
                         self.navigationController?.pushViewController(nextvc, animated: true)
                    }else {
                        print(data.status)
                    }
                    
                   
                }
                
            case .failure(let error):
                print(error)
            }
        }
    }
    
    @IBAction func Forgot(_ sender: Any) {
        let nextvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ForgotPasswordVC")as!ForgotPasswordVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    
    func SelectProfileLogin(){
        if UserDefaultsManager.shared.getUserName() == "Admin" {
            userName.placeholder = "Admin"
            userLbl.text = "Enter Admin and password"
        }
        else if UserDefaultsManager.shared.getUserName() == "User" {
            userName.placeholder = "User"
            userLbl.text = "Enter username and password"
        }
    }
    
    
    

}
