//
//  HistoryVC.swift
//  Venue
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class HistoryVC: UIViewController {
    var eventDetails: [HistoryClass] = [] // Initialize as an empty array
       
       @IBOutlet weak var tableView: UITableView! {
           didSet {
               tableView.delegate = self
               tableView.dataSource = self
           }
       }

    override func viewDidLoad() {
        super.viewDidLoad()
        apiIntegration()

        // Do any additional setup after loading the view.
    }
    
    func apiIntegration() {
        APIHandler().getAPIValues(type: HistoryStruct.self, apiUrl: "http://192.168.179.232/ios/shistory.php", method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                
                DispatchQueue.main.async {
                    if data.status == true {
                        self.eventDetails = data.data
                        self.tableView.reloadData()
                    } else {
                        print(data.status)
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension HistoryVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventCellTableViewCell", for: indexPath) as! EventCellTableViewCell
        
        let event = eventDetails[indexPath.row]
        // Configure the cell with data from the event
        cell.venueLabel.text = event.venue
        cell.titleLabel.text = event.title
        cell.dateLabel.text = event.date
        cell.startTimeLabel.text = event.startTime
        cell.endTimeLabel.text = event.endTime
        
        return cell
    }
}

func History(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


