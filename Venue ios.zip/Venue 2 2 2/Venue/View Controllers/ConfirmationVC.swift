//
//  ConfirmationVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class ConfirmationVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        DispatchQueue.main.async {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
    }
    
}
