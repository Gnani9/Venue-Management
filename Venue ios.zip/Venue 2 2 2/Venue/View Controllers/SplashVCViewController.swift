//
//  SplashVCViewController.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class SplashVCViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectProfileVC")as! SelectProfileVC
            self.navigationController?.pushViewController(nextvc, animated: true)
        }
        
    }
    

}
