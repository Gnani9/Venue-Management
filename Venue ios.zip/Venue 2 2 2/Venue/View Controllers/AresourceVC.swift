import UIKit

class AresourceVC: UIViewController {
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var DesignationTextField: UITextField!
    var detailsData:ResGetModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl.addAction(for: .tap) {
            
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UresourceVC")as!UresourceVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
        }
        // Do any additional setup after loading the view.
    }
    func ResGetPostAPI(){
       let apiUrl = "http://192.168.179.232/ios/iresourceperson.php"

        let parameters:[String : String] = [
            "name": NameTextField.text ?? "" , "designation":DesignationTextField.text ?? ""]
        APIHandler().postAPIValues(type:ResGetModel.self,apiUrl: apiUrl, method: "POST", formData: parameters) { Result in
            switch Result {
            case .success(let Data):
                print(Data)
                DispatchQueue.main.async {
                  let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ConfirmationVC")as!ConfirmationVC;
                 self.navigationController?.pushViewController(nextvc, animated: true)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
       

    
    @IBAction func Addvenue(_ sender: Any) {
        ResGetPostAPI()
    }
    
    

}
