//
//  EprofileVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class EprofileVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func save(_ sender: Any) {
        // Inside the presented view controller
        self.dismiss(animated: true, completion: nil)

    }
    
    

}
