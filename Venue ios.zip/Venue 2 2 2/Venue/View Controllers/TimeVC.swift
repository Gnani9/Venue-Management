//
//  TimeVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class TimeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func conn(_ sender: Any) {
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AresourceVC")as!AresourceVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    

}
