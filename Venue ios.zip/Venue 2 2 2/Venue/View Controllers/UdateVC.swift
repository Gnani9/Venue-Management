//
//  UdateVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class UdateVC: UIViewController {

    @IBOutlet weak var availSeats: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var date: UILabel!
    
    var dateData : DateModel!
    var id = String()
    override func viewDidLoad() {
        super.viewDidLoad()

        self.GetAPI()
    }
    
    @IBAction func UConfirmationVC(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UConfirmationVC") as! UConfirmationVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    
    
    func GetAPI(){
        APIHandler().getAPIValues(type: DateModel.self, apiUrl: "http://192.168.179.232/ios/sdate.php?id=\(id.self)", method: "GET")
        {
            result in
            switch result {
            case .success(let data):
                self.dateData = data
                print(self.dateData ?? "")
                DispatchQueue.main.async {
                    self.date.text = "Date :\(self.dateData.data?.first?.date ?? "")"
                    let time = "\(self.dateData.data?.first?.starttime ?? "") to \(self.dateData.data?.first?.endtime ?? "" )"
                self.time.text = "Time : \(time)"
            }
//                self.availSeats.text = dateData.data.first.av
            case .failure(let error):
                print(error)

            }
        }

    }
}
