//
//  SignupVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class SignupVC: UIViewController {
    @IBOutlet weak var signupsave: UIButton!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func signupsave(_ sender: Any) {
        signupAPI()
//        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC")as!LoginVC;
//        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    
    func signupAPI() {
        let formData: [String: String] = [

            "uusername": username.text ?? "",
            "name": name.text ?? "",
            "email": email.text ?? "",
            "mobile_no": phone.text ?? "",
            "upassword": password.text ?? "",
           
        ]
        APIHandler().postAPIValues(type: SignUpStruct.self, apiUrl: Constants.serviceType.signUpUrl.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.success)")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    

                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}

