//
//  AddDetailsVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class AddDetailsVC: UIViewController {
    
    @IBOutlet weak var add: UITabBarItem!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var floorTextField: UITextField!
    @IBOutlet weak var capacityTextField: UITextField!
    
    
    var detailsData : AddDetailsModel!

    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    func AddDetailsPOSTAPI(){
        
        let parameters: [String: String] = [
            "title": titleTextField.text ?? "",
            "floor": floorTextField.text ?? "",
            "capacity": capacityTextField.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: AddDetailsModel.self, apiUrl: "http://192.168.179.232/ios/igetdetails.php", method: "POST", formData: parameters) { Result in
            switch Result {
            case .success(let Data):
                print(Data)
                DispatchQueue.main.async {
                    let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VenueVC") as! VenueVC
                    self.navigationController?.pushViewController(nextvc, animated: true)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    
    func apiIntegration(){
        
        
            // Define your API URL
            let apiUrl = "http://192.168.66.232/ios/igetdetails.php"
            
            // Create a dictionary to represent your request parameters
            let parameters: [String: String] = [
                "title": titleTextField.text ?? "",
                "floor": floorTextField.text ?? "",
                "capacity": capacityTextField.text ?? ""
            ]
            
            // Convert the parameters to JSON data
            if let jsonData = try? JSONSerialization.data(withJSONObject: parameters) {
                // Create the URL
                if let url = URL(string: apiUrl) {
                    var request = URLRequest(url: url)
                    request.httpMethod = "POST"
                    request.httpBody = jsonData
                    
                    // Set the content type
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    
                    // Create a URLSession task to send the request
                    let task = URLSession.shared.dataTask(with: request) { data, response, error in
                        if let error = error {
                            print("Error: \(error)")
                        } else if let data = data {
                            print(data)
                            do {
                                let result = try JSONDecoder().decode(LoginStruct.self, from: data)
                                print(result)
                                
                                DispatchQueue.main.async {
                                    if result.status == true {
                                        // Handle success, e.g., navigate to the next view controller
                                    } else {
                                        print(result.status)
                                    }
                                }
                            } catch {
                                print("JSON decoding error: \(error)")
                            }
                        }
                    }
                    
                    // Start the URLSession task
                    task.resume()
                }
            }
        

    }
    

    @IBAction func continueButton(_ sender: Any) {
        self.AddDetailsPOSTAPI()
      
    }
    
    

    
}
