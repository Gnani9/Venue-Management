//
//  EventVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class EventVC: UIViewController {
    
    var eventData: EventStruct?{
        didSet{
            if let eventDatas = eventData {
                print(eventDatas)
            }
            else {
                print("No Data In API")
            }
        }
    }// Initialize as an empty array
    
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.delegate = self
            tableView.dataSource = self
        }
    }
    
    @IBOutlet weak var userNameLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if UserDefaultsManager.shared.getUserName() == "User"{
            userNameLbl.text = "User"
        }
        else if UserDefaultsManager.shared.getUserName() == "Admin" {
            userNameLbl.text = "Admin"
        }
        apiIntegration()
    }
    
    func apiIntegration() {
        APIHandler().getAPIValues(type: EventStruct.self, apiUrl: "http://192.168.179.232/ios/iadddetails.php", method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.eventData = data
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension EventVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventData?.data?.count ?? 0
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventCellTableViewCell", for: indexPath) as! EventCellTableViewCell
        
        let event = eventData?.data?[indexPath.row]
        // Configure the cell with data from the event
        
        cell.venueLabel.text = "Location : \(event?.venueName ?? "")"
        cell.titleLabel.text = "Event Titile : \(event?.title ?? "")"
        cell.dateLabel.text = "Date : \(event?.date ?? "")"
        cell.startTimeLabel.text = "Start Time : \(event?.starttime ?? "")"
        cell.endTimeLabel.text = "End Time : \(event?.endtime ?? "")"
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "EventCellTableViewCell", for: indexPath) as! EventCellTableViewCell
        if UserDefaultsManager.shared.getUserName() == "User"{     
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UresourceVC") as! UresourceVC
            nextVC.id = eventData?.data?[indexPath.row].id ?? ""
            self.navigationController?.pushViewController(nextVC, animated: true)
        }

    }
}




