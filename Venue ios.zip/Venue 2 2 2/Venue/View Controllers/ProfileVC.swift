//
//  ProfileVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class ProfileVC: UIViewController {

    @IBOutlet weak var profileImg: UIImageView!
    
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var EmailLabel: UILabel!
    @IBOutlet weak var PhoneLabel: UILabel!
    let apiHandler : APIHandler = APIHandler()
     var apiData : ProfileJSON!
     var apiUrl = String()

    override func viewDidLoad() {
        super.viewDidLoad()
//        profileImg.addAction(for: .tap) {
//            self.profileImg.image = UIImage(named: "Rectangle 45-1")
//        }
    
    }
    
    

    
    @IBAction func edit(_ sender: Any) {
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EprofileVC")as!EprofileVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
       GetAPI()

       }

       
       func GetAPI(){
           
           APIHandler().getAPIValues(type: ProfileJSON.self, apiUrl: Constants.serviceType.ProfileAPI, method: "GET") {
               result in
               switch result {
               case .success(let data):
                   self.apiData = data
                   print(data)
                   DispatchQueue.main.async { [self] in [self];
                       self.NameLabel.text = "Name: \(self.apiData.data.first?.username ?? "")"
                       self.EmailLabel.text = "Email: \(self.apiData.data.first?.email ?? "")"
                       self.PhoneLabel.text = "Phone: \(self.apiData.data.first?.phone ?? "")"
                       
                   }
                   
                   
               case .failure(let error):
                   print(error)
                   
               }
           }
           
       }


    
}
 
