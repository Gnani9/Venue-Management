//
//  ForgotPasswordVC.swift
//  Venue
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class ForgotPasswordVC: UIViewController {
    @IBOutlet weak var Forgotsave: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Forgotsave(_ sender: Any) {
        let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC")as!LoginVC;
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    
    
}
